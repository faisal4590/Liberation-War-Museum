create table war_criminal
(

name varchar(100),
crimes varchar(100),
battle varchar(100),
nationality varchar(100),
arrest_date date,
sentence varchar(100),
date_of_execution date,
date_of_conviction date


);