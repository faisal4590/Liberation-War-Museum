create table forces
(

rank varchar(155),
forces_type varchar(155),
nation varchar(155),
chief varchar(155),
manpower varchar(155)


);