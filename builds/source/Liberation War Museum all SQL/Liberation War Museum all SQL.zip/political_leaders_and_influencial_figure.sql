create table political_leaders
(

name varchar(100),
fathers_name varchar(100),
mothers_name varchar(100),
date_of_birth date,
gender varchar(100),
recognition varchar(100),
spouse varchar(100),
profession varchar(100)


);